﻿using System;
using System.Collections.Generic;
public struct Mokinys
{
    public string vardas, pavarde;
    public int n;
    public List<int> nd;
    public int egz;
    public double vid;
    public int med;
    public double galutinisvid;
    public double galutinismed;
    public Random random;
    public void enterdataman(string v,string p, List<int> n, int e)
    {
        vardas = v;
        pavarde = p;
        nd = n;
        egz = e;
        nd.Sort();
        med = nd[nd.Count / 2];
        int sum = 0;
        for(int i=0;i<nd.Count;i++)
        {
            sum += nd[i];
        }
        vid = Convert.ToDouble(sum / nd.Count);
        galutinisvid=vid*0.3+egz*0.7;
        galutinismed = Convert.ToDouble(med * 0.3) + Convert.ToDouble(egz * 0.7);
        
    }
    public void enterdata()
    {
        Console.WriteLine("Įveskite mokinio vardą: ");
        vardas = Console.ReadLine();
        Console.WriteLine("Įveskite mokinio pavardę: ");
        pavarde = Console.ReadLine();
        int m4;

        do
        {
            Console.WriteLine("Jei norite, kad pažymius sugeneruotų atsitiktinai, spauskite 1,\n jeigu norite pažymius įvesti patys, spauskite 2");
            m4 = Convert.ToInt32(Console.ReadLine());
            if ((m4 != 1) && (m4 != 2))
            {
                Console.WriteLine("Įvedėte neteisingai, pakartokite.");
            }
        } while ((m4 != 1) && (m4 != 2));
        Console.WriteLine("Ar iš anksto yra žinomas atliktų namų darbų skaičius?\n Jeigu taip, spauskite 1, jeigu ne, spauskite 2");
        int m2 = Convert.ToInt32(Console.ReadLine());
        int sum = 0;
        nd = new List<int>();
        random = new Random();
        if (m2 == 1)
        {
            Console.WriteLine("Iveskite kiek namų darbų atlikta: ");
            n = Convert.ToInt32(Console.ReadLine());
            
            
            
            sum = 0;

            for (int i = 0; i < n; i++)
            {
                if (m4 == 1)
                {
                    nd.Add(random.Next(1, 10));
                }
                else if (m4 == 2)
                {
                    Console.WriteLine("Iveskite  namu darbo pažimį");
                    nd.Add(Convert.ToInt32(Console.ReadLine()));
                }
                sum = sum + nd[i];
            }
            nd.Sort();
            med = nd[nd.Count / 2];

        }

        else if (m2 == 2)
        {
            int m3;
            sum = 0;
            int j = 0;
            do
            {
                Console.WriteLine("Ar norite įvesti naują namų darbą? Jeigu taip, spauskite 1");
                m3 = Convert.ToInt32(Console.ReadLine());
                if (m3 == 1)
                {
                    if (m4 == 1)
                    {
                        nd.Add(random.Next(1, 10));
                    }
                    else if (m4 == 2)
                    {
                        Console.WriteLine("Iveskite namu darbo pažimį");
                        nd.Add(Convert.ToInt32(Console.ReadLine()));
                    }
                    sum += nd[j];
                }
            } while (m3 == 1);
            n = nd.Count;
            nd.Sort();
            med = nd[nd.Count / 2];
        }
        else
        {
            Console.WriteLine("Neteisingai įvedėte.");
        }
        
        if (m4 == 1) { egz = random.Next(1, 10); }
        else if (m4 == 2)
        {
            Console.WriteLine("Iveskite egzamino pažymį: ");
            egz = Convert.ToInt32(Console.ReadLine());
        }
        vid = Convert.ToDouble(sum / n);
        //printtarp();
        galutinisvid = vid * 0.3 + Convert.ToDouble(egz * 0.7);
        galutinismed = Convert.ToDouble(med * 0.3) + Convert.ToDouble(egz * 0.7);
    }
    public void printvid()
    {
        Console.WriteLine("{0,20}{1,20}{2,20:0.00}", vardas, pavarde, galutinisvid);

    }
    public void printtarp()
    {
        Console.Write("Namų darbai: ");
        nd.ForEach(item => Console.Write(item+";"));
        Console.WriteLine("Egzaminas="+egz+" vid(nd)="+vid+" med(nd)"+med);
    }
    public void printoof()
    {
        Console.WriteLine("{0,-20}{1,-20}{2,-20}{3,-20}", pavarde, vardas, galutinisvid, galutinismed);
    }
    public void printmed()
    {

        Console.WriteLine("{0,20}{1,20}{2,20:0.00}", vardas, pavarde, galutinismed);
    }
}