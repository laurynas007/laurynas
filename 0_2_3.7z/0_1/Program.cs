﻿using System;
using System.IO;
using System.Collections.Generic;


   
    
    class Program
    {
        public void menu()
        {
            List<Mokinys> mokiniai = new List<Mokinys>();
            int men;
            do
            {
                Console.WriteLine("Jeigu norite įvesti naują mokinį spauskite 1,\n Jeigu norite perskaityti mokinių sąrašą iš failo ir jį apdorojus atspausdinti, spaukite 2, \n jeigu norite matyti visų mokinių sąrašą - spauskite 3,\n jeigu norite, kad programa baigtų darbą, spauskite 0");
                men = Convert.ToInt32(Console.ReadLine());
                if (men == 1)
                {
                    Mokinys mok = new Mokinys();
                    mok.enterdata();
                    mokiniai.Add(mok);
                }
                else if(men==2)
            {
                String[] lines = System.IO.File.ReadAllLines("studentai.txt");
                int l = 0;
                foreach (string line in lines)
                {
                    if (l != 0)
                    {
                        
                        List<string> ele = new List<string>(line.Split(' ', StringSplitOptions.RemoveEmptyEntries));
                        string var = ele[0];
                        string pav = ele[1];
                        List<int> n = new List<int>();
                        for (int i = 2; i < ele.Count - 1; i++)
                        {
                            n.Add(Convert.ToInt32(ele[i]));
                        }
                        int eg = Convert.ToInt32(ele[ele.Count - 1]);
                        Mokinys mok = new Mokinys();
                        mok.enterdataman(var, pav, n, eg);
                        mokiniai.Add(mok);

                        //Console.WriteLine("{0,0} {1,0} {2,0} {3, 0}",var, pav, string.Join("; ", n), eg);
                    }
                    l++;
                }
                mokiniai.Sort((s1,s2)=>s1.pavarde.CompareTo(s2.pavarde));
                Console.WriteLine("{0,-20}{1,-20}{2,-20}{3,-20}", "Pavarde", "Vardas", "Galutinis(vid)", "Galutinis(Med.)");
                for(int i=0;i<mokiniai.Count;i++)
                {
                    mokiniai[i].printoof();
                }
            }
                    else if (men == 3)
                {
                mokiniai.Sort((s1, s2) => s1.vardas.CompareTo(s2.vardas));
                int men4;
                    Console.WriteLine("Jeigu norite kad galutinis pažimys būtų spausdinamas pagal namų darbų vidurkį, spauskite 1,\n jeigu norite kad galutinis pažimys būtų spausdinamas pagal medianą, spauskite 0");
                    men4 = Convert.ToInt32(Console.ReadLine());
                    if (men4 == 1)
                    {
                        Console.WriteLine("{0,20}{1,20}{2,20}", "Vardas", "Pavarde", "Galutinis(vid)");
                        for (int i = 0; i < mokiniai.Count; i++)
                        {
                            mokiniai[i].printvid();
                        }

                    }
                    else if (men4 == 0)
                    {


                        Console.WriteLine("{0,20}{1,20}{2,20}", "Vardas", "Pavarde", "Galutinis(med)");
                        for (int i = 0; i < mokiniai.Count; i++)
                        {
                            mokiniai[i].printmed();
                        }

                    }

                }
            } while (men != 0);
            Console.WriteLine("Programa darbą baigė");
        
    }
        static void Main(string[] args)
        {
           try
        {
            if (!File.Exists("studentai.txt"))
                throw new FileNotFoundException();
            else Console.WriteLine("File studentai.txt is found");
        }
        catch (FileNotFoundException e)
        {
            Console.WriteLine("File studentai.txt not found");
        }

            Program m = new Program();
            m.menu();
            Console.ReadKey();
      
        }

    
    }


