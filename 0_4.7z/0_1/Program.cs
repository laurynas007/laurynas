﻿using System;
using System.IO;
using System.Collections.Generic;


   
    
    class Program
    {
    public Random random=new Random();
    public List<Mokinys> mokiniai = new List<Mokinys>();
     public void Menu()
        {
           
            int men;
            do
            {
                Console.WriteLine("Jeigu norite įvesti naują mokinį spauskite 1,\n Jeigu norite perskaityti mokinių sąrašą iš failo ir jį apdorojus atspausdinti, spaukite 2, \n jeigu norite matyti visų mokinių sąrašą - spauskite 3,\n jeigu norite sugeneruoti atsitiktinių įrašų failą ir jį apdoroti, spauskite 4, \n jeigu norite, kad programa baigtų darbą, spauskite 0");
                men = Convert.ToInt32(Console.ReadLine());
                if (men == 1)
                {
                    Mokinys mok = new Mokinys();
                    mok.Enterdata();
                    mokiniai.Add(mok);
                }
                else if(men==2)
            {
                String[] lines = System.IO.File.ReadAllLines("studentai.txt");
                int l = 0;
                foreach (string line in lines)
                {
                    if (l != 0)
                    {
                        
                        List<string> ele = new List<string>(line.Split(' ', StringSplitOptions.RemoveEmptyEntries));
                        string var = ele[0];
                        string pav = ele[1];
                        List<int> n = new List<int>();
                        for (int i = 2; i < ele.Count - 1; i++)
                        {
                            n.Add(Convert.ToInt32(ele[i]));
                        }
                        int eg = Convert.ToInt32(ele[ele.Count - 1]);
                        Mokinys mok = new Mokinys();
                        mok.Enterdataman(var, pav, n, eg);
                        mokiniai.Add(mok);

                        //Console.WriteLine("{0,0} {1,0} {2,0} {3, 0}",var, pav, string.Join("; ", n), eg);
                    }
                    l++;
                }
                mokiniai.Sort((s1,s2)=>s1.pavarde.CompareTo(s2.pavarde));
                Console.WriteLine("{0,-20}{1,-20}{2,-20}{3,-20}", "Pavarde", "Vardas", "Galutinis(vid)", "Galutinis(Med.)");
                for(int i=0;i<mokiniai.Count;i++)
                {
                    mokiniai[i].Printoof();
                }
            }
                    else if (men == 3)
                {
                mokiniai.Sort((s1, s2) => s1.vardas.CompareTo(s2.vardas));
                int men4;
                    Console.WriteLine("Jeigu norite kad galutinis pažimys būtų spausdinamas pagal namų darbų vidurkį, spauskite 1,\n jeigu norite kad galutinis pažimys būtų spausdinamas pagal medianą, spauskite 0");
                    men4 = Convert.ToInt32(Console.ReadLine());
                    if (men4 == 1)
                    {
                        Console.WriteLine("{0,20}{1,20}{2,20}", "Vardas", "Pavarde", "Galutinis(vid)");
                        for (int i = 0; i < mokiniai.Count; i++)
                        {
                            mokiniai[i].Printvid();
                        }

                    }
                    else if (men4 == 0)
                    {


                        Console.WriteLine("{0,20}{1,20}{2,20}", "Vardas", "Pavarde", "Galutinis(med)");
                        for (int i = 0; i < mokiniai.Count; i++)
                        {
                            mokiniai[i].Printmed();
                        }

                    }

                }
                else if (men==4)
            {

                //Console.WriteLine("įveskite kiek failų ruošiaties generuoti");
                int f = 5;
                int fi = 100;//Convert.ToInt32(Console.ReadLine());
                for(int i=1;i<=f;i++)
                {
                    string filename = Convert.ToString(i) + ".txt";
                    Console.WriteLine("generuojamas "+filename);
                    fi *= 10; 
                    string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                    StreamWriter outputFile = new StreamWriter(Path.Combine(docPath, filename));
                    
                        outputFile.WriteLine("Vardas Pavarde nd1 nd2 nd3 nd4 nd5 Egzaminas");
                        for(int j=1;j<=fi;j++)
                        {
                            string vardas = "Vardas" + Convert.ToString(j);
                            string pavarde = "Pavarde" + Convert.ToString(j);
                            int nd1= random.Next(1, 10);
                            int nd2 = random.Next(1, 10);
                            int nd3 = random.Next(1, 10);
                            int nd4 = random.Next(1, 10);
                            int nd5 = random.Next(1, 10);
                            int egz=random.Next(1, 10); 
                            string stud=vardas+" "+pavarde+" "+Convert.ToString(nd1) + " " + Convert.ToString(nd2) + " " + Convert.ToString(nd3) + " " + Convert.ToString(nd4)+" " + Convert.ToString(nd5) + " " + Convert.ToString(egz);
                        outputFile.WriteLine(stud);
                        List<int> nd = new List<int>();
                            nd.Add(nd1);
                            nd.Add(nd2);
                            nd.Add(nd3);
                            nd.Add(nd4);
                            nd.Add(nd5);
                            Mokinys mok = new Mokinys();
                            mok.Enterdataman(vardas,pavarde,nd,egz);
                            mokiniai.Add(mok);
                        }
                        mokiniai.Sort((s1, s2) => s1.galutinisvid.CompareTo(s2.galutinisvid));

                    
                    
                }
                Console.WriteLine("Sukategoruojama į failus");
                string kat2 = "galvociai.txt";
                string kat1 = "vargsiukai.txt"; 
                    string docPat = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                StreamWriter outkat2 = new StreamWriter(Path.Combine(docPat, kat2), true);
                StreamWriter outkat1 = new StreamWriter(Path.Combine(docPat, kat1), true);
                outkat2.WriteLine("{0,30}{1,20}{2,20}", "Vardas", "Pavarde", "Galutinis(vid)");
                outkat1.WriteLine("{0,20}{1,20}{2,20}", "Vardas", "Pavarde", "Galutinis(vid)");
                for (int k=0;k<mokiniai.Count;k++)
                {
                    mokiniai[k].PrintFile(outkat1, outkat2);
                }
                Console.WriteLine("Galutiniai failai bus sugeneruojami tvarkingai baigiant darba.");

            }
            } while (men != 0);
            Console.WriteLine("Programa darbą baigė");
        
    }
        static void Main(string[] args)
        {
           try
        {
            if (!File.Exists("studentai.txt"))
                throw new FileNotFoundException();
            else Console.WriteLine("File studentai.txt is found");
        }
        catch (FileNotFoundException e)
        {
            Console.WriteLine("File studentai.txt not found");
        }

            Program m = new Program();
            m.Menu();
            Console.ReadKey();
      
        }

    
    }


